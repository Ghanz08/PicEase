const url = window.location.href;

if (url.includes("/login")) {
  document.getElementById("inihome").style.display = "none";
}
